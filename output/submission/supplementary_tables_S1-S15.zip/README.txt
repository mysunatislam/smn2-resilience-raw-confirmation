Supplementary Tables S1-S15 for the frozen SMA motor-neuron resilience analysis.
Files are tab-delimited UTF-8 text and should be cited by supplementary table number.
